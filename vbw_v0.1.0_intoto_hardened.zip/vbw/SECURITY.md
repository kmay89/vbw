# Security Policy

## Reporting a Vulnerability

**Do not open public issues for security vulnerabilities.**

Email: security@scqcs.dev

Include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

We will respond within 48 hours.

## Supported Versions

| Version | Supported |
| ------- | --------- |
| 0.1.x   | ✅        |

## Security model

VBW's guarantee is structural:

1. **No access required** — we cannot leak what we never see
2. **Cryptographic verification only** — checks operate on signed evidence
3. **Transparent operation** — verification is reproducible from the bundle
4. **Open source** — code is auditable

If VBW ever requests credentials, private keys, or internal network access: **that's a bug**.
