# VBW — Verified Build Witness

**Zero-knowledge build integrity verification using SLSA + in-toto + Sigstore.**

VBW’s value-add is a thin, auditable policy layer: **independence enforcement**.
If a build *requires* internal access, private networks, or secrets, VBW treats that as a policy failure.

## Quick start

### Build
```bash
cargo build --release
```

### Install external tools (optional but recommended)
```bash
# SLSA verifier
go install github.com/slsa-framework/slsa-verifier/v2/cli/slsa-verifier@latest

# in-toto
pip install in-toto

# Sigstore (cosign)
go install github.com/sigstore/cosign/v2/cmd/cosign@latest
```

### Verify the example bundle
The example is designed to be runnable without external tooling:

```bash
./target/release/vbw verify examples/minimal-bundle --no-external --dry-run --slsa-mode schema-only
cat examples/minimal-bundle/vbw/report.json
```

### Verify a real bundle (full mode)
```bash
vbw verify ./bundle \
  --artifact ./bundle/myapp \
  --source-uri github.com/org/repo
```

## Inspect an attestation (when present)
```bash
vbw show \
  --attestation bundle/vbw/vbw-attestation.json \
  --sigstore-bundle bundle/vbw/vbw-attestation.sigstore.bundle
```

## Bundle structure
```
bundle/
├── provenance.json          # SLSA provenance
├── layout.json              # in-toto layout
├── links/                   # in-toto attestations (*.link)
├── artifacts/               # (optional) binaries to verify
├── vbw-policy.json          # (optional) custom policy
└── vbw/                     # VBW output
    ├── vbw-attestation.json
    ├── vbw-attestation.sigstore.bundle
    └── report.json
```

## Policy configuration
Create `vbw-policy.json`:

```json
{
  "allowed_builder_prefixes": [
    "https://github.com/",
    "https://gitlab.com/"
  ],
  "builder_allowlist_is_warning": true,
  "forbid_private_network_refs": true,
  "forbid_secrets": true,
  "require_digests": true
}
```

## Docs
- `ARCHITECTURE.md` — composition model + threat boundaries
- `examples/DEMO.md` — reproducible demo workflow
- `SECURITY.md` — vulnerability disclosure

## License
Apache-2.0
